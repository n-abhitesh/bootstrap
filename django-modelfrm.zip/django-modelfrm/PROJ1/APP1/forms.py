from django import forms
from APP1.models import Feedback


class FeedbackForm(forms.ModelForm):
    class Meta:
        model=Feedback
        fields='__all__'