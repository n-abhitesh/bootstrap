from django.shortcuts import render

from . import forms


def feedbackData(request):
    form=forms.FeedbackForm()
    if request.method=='POST':
        form=forms.FeedbackForm(request.POST)
        if form.is_valid():
            form.save(commit=True)
    return render(request, 'input.html', {'form':form})

# Create your views here.
