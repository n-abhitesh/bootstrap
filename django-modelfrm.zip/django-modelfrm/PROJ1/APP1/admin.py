from django.contrib import admin
from APP1.models import Feedback

class FeedbackAdmin(admin.ModelAdmin):
    list_display=['name', 'rollno']
admin.site.register(Feedback, FeedbackAdmin)
# Register your models here.
