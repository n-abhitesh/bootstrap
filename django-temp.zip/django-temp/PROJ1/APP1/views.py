from django.shortcuts import render
import datetime

def message(request):
    x=datetime.datetime.now()
    msg="hello"
    hours=int(x.strftime('%H'))
    if hours<12:
        msg+='good morning'
    elif hours<15:
        msg+='good afternoon'
    else:
        msg+='yoyo hey'
    my_dict={'cur_date':x, 'snd_msg':msg}
    return render(request, 'index.html', context=my_dict)


# Create your views here.
