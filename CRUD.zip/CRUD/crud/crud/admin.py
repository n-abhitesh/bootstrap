from django.contrib import admin
from crud.models import Stud

# Register your models here.
admin.site.register(Stud)