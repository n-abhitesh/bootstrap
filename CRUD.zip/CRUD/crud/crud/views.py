from django.shortcuts import render, redirect

# Create your views here.
from crud.forms import StudForm  
from crud.models import Stud  
# Create your views here.  
def stu(request):  
    if request.method == "POST":  
        form = StudForm(request.POST)  
        if form.is_valid():  
            try:  
                form.save()  
                return redirect('/show')  
            except:  
                pass  
    else:  
        form = StudForm()  
    return render(request,'crudt/this.html',{'form':form})  
def show(request):  
    students = Stud.objects.all()  
    return render(request,"crudt/show.html",{'students':students})  
def edit(request, id):  
    student = Stud.objects.get(id=id)  
    return render(request,'crudt/edit.html', {'student':student})  
def update(request, id):  
    student = Stud.objects.get(id=id)  
    form = StudForm(request.POST, instance = student)  
    if form.is_valid():  
        form.save()  
        return redirect("/show")  
    return render(request, 'crudt/edit.html', {'student': student})  
def destroy(request, id):  
    student = Stud.objects.get(id=id)  
    student.delete()  
    return redirect("/show")  