from django import forms  
from crud.models import Stud
  
class StudForm(forms.ModelForm):  
    class Meta:  
        model = Stud  
        fields = "__all__" 