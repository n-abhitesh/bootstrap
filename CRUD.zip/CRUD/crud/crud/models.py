from django.db import models

# Create your models here.
class Stud(models.Model):
    sname=models.CharField(max_length=25)
    smail=models.EmailField(max_length=40)
    scity=models.CharField(max_length=30)
    smobile=models.IntegerField()
    sgender=models.CharField(max_length=1)

class Meta:  
        db_table = "student"
    