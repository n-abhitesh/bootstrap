from django.shortcuts import render
from newapp.models import Student

def studentdata(request):
    stud_list = Student.objects.all()
    return render(request, "result.html", {'stud_list': stud_list})
