from django.contrib import admin
from django.urls import path
from APP1 import views as v

urlpatterns = [
    path('admin/', admin.site.urls),
    path('get/', v.get_session),
    path('set/', v.set_session),
    path('getc/', v.get_cookie),
    path('setc/', v.set_cookie),

]
