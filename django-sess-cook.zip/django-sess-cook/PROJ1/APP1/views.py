from django.http import HttpResponse

def set_session(request):
    request.session['username'] = 'abhitesh'
    return HttpResponse("Session set successfully!")

def get_session(request):
    username = request.session.get('username', 'Default Username')
    return HttpResponse(f"Username: {username}")


def set_cookie(request):
    response=HttpResponse('cookie set')
    response.set_cookie('fav_col', 'blue')
    return response

def get_cookie(request):
    color = request.COOKIES.get('fav_col')
    return HttpResponse(f'Favorite color: {color}')