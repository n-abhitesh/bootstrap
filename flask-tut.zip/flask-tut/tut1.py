from flask import Flask, render_template
app = Flask(__name__)
@app.route('/')
def home():
    # Pass data to the template
    video_title = 'Hope You Will Like This Video'
    description = 'This is a way for me to teach Flask nicely'
    # Render the template with the provided data
    return render_template('about.html', video_title=video_title, description=description)
if __name__ == '__main__':
    app.run()

#flask --app tut1 run