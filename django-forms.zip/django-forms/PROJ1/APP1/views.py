from django.shortcuts import render
from . import forms


# Create your views here.

def studentData(request):
    form=forms.StudentForm()
    if request.method=='POST':
        form=forms.StudentForm(request.POST)
        if form.is_valid():
            print(form.cleaned_data['roll'])
            print(form.cleaned_data['name'])
    else:
        form=forms.StudentForm()
    return render(request, 'index.html', {'form':form})